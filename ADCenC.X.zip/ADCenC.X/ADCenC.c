/*
 * File:   ADCenC.c
 * Author: Emanuel
 *
 * Created on 23 de octubre de 2020, 10:44 PM
 */
#include <xc.h>
#define _XTAL_FREQ 8000000
// CONFIG1
#pragma config FOSC = INTRC_CLKOUT 
#pragma config WDTE = OFF       
#pragma config PWRTE = ON       
#pragma config MCLRE = ON       
#pragma config CP = OFF         
#pragma config CPD = OFF        
#pragma config BOREN = ON       
#pragma config IESO = ON        
#pragma config FCMEN = ON       
#pragma config LVP = OFF        


#pragma config BOR4V = BOR40V   
#pragma config WRT = OFF        

int adc=0;
int adc1=0;
void main(void) {
    OSCCONbits.IRCF=0b1110;
    OSCCONbits.SCS=0b00;
    ANSEL=0B00000001;
    ANSELH=0B00000000;
    ADCON0bits.ADON=1;
    ADCON0bits.GO_nDONE=0;
    ADCON0bits.CHS=0000;
    ADCON0bits.ADCS=10;
    ADCON1bits.ADFM=0;
    ADCON1bits.VCFG0=0;
    ADCON1bits.VCFG1=0;
    TRISA=0b00000001;
    TRISD=0b00000000;
    TRISB=0b00000000;
     TRISC=0b00000000;
    PORTD=0b00000000;
    PORTB=0b00000000;
    PORTC=0b00000000;
    __delay_ms(100);
    while(1){
        ADCON0bits.GO_nDONE=1;
        while(ADCON0bits.GO_nDONE){
        adc=ADRESH;
        PORTD=ADRESH;
        adc1=ADRESL;
        PORTC=adc1;
        }
    }
    return;
}
